import React from "react";

function SolarizedCredit() {
    return (
        <p id="style-reference">
            Color palette based on Solarized Dark Theme for IDEs and text editors.
        </p>
    );
}

export default SolarizedCredit;